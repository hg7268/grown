import React from "react";

const TestimonialCard = () => {
	return <div>TestimonialCard</div>;
};

export default TestimonialCard;
